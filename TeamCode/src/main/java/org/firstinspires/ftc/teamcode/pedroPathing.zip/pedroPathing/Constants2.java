//package org.firstinspires.ftc.teamcode.pedroPathing;
//
//import com.pedropathing.follower.Follower;
//import com.pedropathing.follower.FollowerConstants;
//import com.pedropathing.ftc.FollowerBuilder;
//import com.pedropathing.ftc.drivetrains.MecanumConstants;
//import com.pedropathing.ftc.localization.constants.PinpointConstants;
//import com.pedropathing.paths.PathConstraints;
//import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
//import com.qualcomm.robotcore.hardware.DcMotorSimple;
//import com.qualcomm.robotcore.hardware.HardwareMap;
//
//import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
//
//
//public class Constants2 {
//
//    public static MecanumConstants driveConstants = new MecanumConstants()
//            .maxPower(1)
//            .xVelocity(83.964288)
//            .yVelocity(59.967970)
//            .rightFrontMotorName("rightFront")
//            .rightRearMotorName("rightBack")
//            .leftRearMotorName("leftBack")
//            .leftFrontMotorName("leftFront")
//            .leftFrontMotorDirection(DcMotorSimple.Direction.REVERSE)
//            .leftRearMotorDirection(DcMotorSimple.Direction.REVERSE)
//            .rightFrontMotorDirection(DcMotorSimple.Direction.FORWARD)
//            .rightRearMotorDirection(DcMotorSimple.Direction.FORWARD);
//
//
//    public static FollowerConstants followerConstants = new FollowerConstants()
//            .mass(15.38)
//            .forwardZeroPowerAcceleration(-33.713) // -34.16422 -34.6427
//            .lateralZeroPowerAcceleration(-77.198); // -77.6366
////            .centripetalScaling(0.005)
////            .translationalPIDFCoefficients(new PIDFCoefficients(0.2, 0, 0.01, 0.04))
////            .headingPIDFCoefficients(new PIDFCoefficients(1, 0, 0.03, .050))
////            .drivePIDFCoefficients(new FilteredPIDFCoefficients(0.025,0.0,0.00001,0.6,0.01));
//
//
//
//    public static PinpointConstants localizerConstants = new PinpointConstants()
//            .forwardPodY(-3.15)
//            .strafePodX(-5)
//            .distanceUnit(DistanceUnit.INCH)
//            .hardwareMapName("Pinpoint")
//            .encoderResolution(GoBildaPinpointDriver.GoBildaOdometryPods.goBILDA_4_BAR_POD)
//            .forwardEncoderDirection(GoBildaPinpointDriver.EncoderDirection.FORWARD)
//            .strafeEncoderDirection(GoBildaPinpointDriver.EncoderDirection.REVERSED);
//
//
//
//
//    public static PathConstraints pathConstraints = new PathConstraints(0.99, 100, 1, 1);
//
//    public static Follower createFollower(HardwareMap hardwareMap) {
//        return new FollowerBuilder(followerConstants, hardwareMap)
//                .pinpointLocalizer(localizerConstants)
//                .pathConstraints(pathConstraints)
//                .mecanumDrivetrain(driveConstants)
//                .build();
//    }
//
//
//}
